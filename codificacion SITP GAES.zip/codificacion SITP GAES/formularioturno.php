<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Programación de Turno</title>
    <link rel="stylesheet" href="formularioturno.css">
</head>
<body>
    <div class="form-container">
        <h2>Programación de Turno</h2>
        <form action="#" method="post">
            <div class="form-group">
                <label for="nombre">Nombre del Empleado:</label>
                <input type="text" id="nombre" name="nombre" required>
            </div>
            <div class="form-group">
                <label for="cargo">Cargo:</label>
                <input type="text" id="cargo" name="cargo" required>
            </div>
            <div class="form-group">
                <label for="tipo_trabajo">Tipo de Trabajo:</label>
                <input type="text" id="tipo_trabajo" name="tipo_trabajo" required>
            </div>
            <div class="form-group">
                <label for="area">Área:</label>
                <input type="text" id="area" name="area" required>
            </div>
            <div class="form-group">
                <label for="tareas">Tareas a Realizar:</label>
                <textarea id="tareas" name="tareas" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="fecha_inicio">Fecha de Inicio:</label>
                <input type="date" id="fecha_inicio" name="fecha_inicio" required>
            </div>
            <div class="form-group">
                <label for="fecha_final">Fecha Final:</label>
                <input type="date" id="fecha_final" name="fecha_final" required>
            </div>
            <div class="form-group">
                <label for="observaciones">Observaciones:</label>
                <textarea id="observaciones" name="observaciones" rows="4"></textarea>
            </div>
            <div class="form-group">
                <button type="submit">Programar Turno</button>
            </div>
        </form>
    </div>
</body>
</html>
