<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario</title>
    <link rel="stylesheet" href="notificacion.css">
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <img src="usuarioturno.PNG" alt="SIPT Tecnogly Logo" class="logo">
            <h1>Roberto Vega</h1>
            <p>Operario industrial Junior</p>
        </div>
        <div class="right-panel">
            <div class="top-right">
                <div class="user-icon"></div>
                <p>Cerrar Sesión</p>
            </div>
            <div class="image-container">
                <img src="phone_image.jpg" alt="Phone Image">
            </div>
        </div>
    </div>
</body>
</html>
