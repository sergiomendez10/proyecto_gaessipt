<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Proyectos</title>
    <link rel="stylesheet" href="modulos.css">
</head>
<body>
<div class="container">
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="sidebar-header">
            <!-- Aquí el logo -->
            <img src="logositppremium.png" alt="Logo" class="logo-circular">
        </div>
        <ul class="menu">
        <li>
    <input type="checkbox" id="menu1">
    <label for="menu1">Registro y gestión de turnos</label>
    <ul class="submenu">
        <li><a href="dashboard.php">Crear Usuario</a></li> <!-- Enlace actualizado -->
        <li><a href="formularioturno.php">Crear Turno</a></li>
        <li><a href="#">Asignar Turno</a></li>
    </ul>
</li>
    <li>
        <input type="checkbox" id="menu2">
        <label for="menu2">Interacción cliente Interfaz</label>
        <ul class="submenu">
            <li><a href="programacion.php">Ver Programacion</a></li>
            <li><a href="#">Solicitar Cambio de Turno</a></li>
        </ul>
    </li>
    <li>
        <input type="checkbox" id="menu3">
        <label for="menu3">Formatos regulatorios e informes</label>
        <ul class="submenu">
            <li><a href="#">Generar Informe de Turnos</a></li>
            <li><a href="#">Restricciones</a></li>
            <li><a href="#">Permisos laborales</a></li>
            <li><a href="#">Nomina</a></li>
        </ul>
    </li>
    <li>
        <input type="checkbox" id="menu4">
        <label for="menu4">Control y gestión de tareas</label>
        <ul class="submenu">
            <li><a href="#">Turnos automáticos</a></li>
            <li><a href="#">Herramientas de Trabajo</a></li>
        </ul>
    </li>
</ul>

    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <header class="topbar">
            <h2>SIPT technology</h2>
            <div class="search-box">
                <input type="text" placeholder="¿Que buscas?">
            </div>
            <div class="user-menu">
                <span>SM</span>
            </div>
        </header>
