<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendario</title>
    <link rel="stylesheet" href="programacion.css">
</head>
<body>
<div class="logo-container">
        <img src="logositppremium.png" alt="Logo" class="logo-small">
      </div>
    <div class="calendar-container">
        <h1>Septiembre</h1>
        <div class="calendar">
            <?php
            // Suponiendo que queremos crear un calendario para los primeros 30 días de septiembre
            for ($day = 1; $day <= 30; $day++) {
                echo '<div class="calendar-day">
                        <p>' . $day . '</p>
                    </div>';
            }
            ?>
        </div>
    </div>
</body>
</html>



